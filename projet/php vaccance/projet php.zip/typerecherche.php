

<form method="POST" action="aiguillage.php">
<p>Choisissez votre methode de filtrage</p>
<select name="type" >
<option>artiste<option>
<option>album<option>
<option>titre<option>
</select>
<input type="submit" value="Envoyer" />
</form>
