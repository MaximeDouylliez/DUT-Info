#include"list.h"
int alea (int bmin,int bmax);
void gen(int multiplicateur,int tranche);
