#include"list.h"
list modsub(int id,list l);
list modsubn(int n,list l);
