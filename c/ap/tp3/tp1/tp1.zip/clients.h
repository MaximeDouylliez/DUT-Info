
//type client comprenant son heure d'arrivée et son heure de départ

typedef struct cl client;




client creer_client (int ar);
//in: on recoit en arguement l'heure d'arrivée
//out: on renvoit le client crée
//action: creer le client avec ses composantes remplis 

int uniform (int min, int max);
// deja faite

