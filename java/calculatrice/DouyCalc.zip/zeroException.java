public class zeroException extends Exception{

public zeroException(){}
}