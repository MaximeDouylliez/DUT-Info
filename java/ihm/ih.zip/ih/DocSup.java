import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.io.IOException;

public class DocSup extends JFrame
{
  
    
    public DocSup(JButton go, JButton ret)
    {
      
    }

}
