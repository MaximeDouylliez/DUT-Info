import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.io.IOException;

public class PreciSite extends JFrame
{
 

    /**
     * Constructor for objects of class PreciSite
     */
    public PreciSite(JButton gopai, JButton godoc, JButton ret)
    {
       
    }

}
